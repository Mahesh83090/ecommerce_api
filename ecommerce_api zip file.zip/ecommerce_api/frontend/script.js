const baseURL = "http://127.0.0.1:8000";
let token = "";
let isAdmin = false;

// UI Display Functions
function showRegister() {
    document.getElementById("loginSection").classList.add("hidden");
    document.getElementById("registerSection").classList.remove("hidden");
}
function showLogin() {
    document.getElementById("registerSection").classList.add("hidden");
    document.getElementById("loginSection").classList.remove("hidden");
}
function showDashboard() {
    document.getElementById("loginSection").classList.add("hidden");
    document.getElementById("registerSection").classList.add("hidden");
    document.getElementById("dashboard").classList.remove("hidden");
}

// 📝 REGISTER
function register() {
    const user = {
        username: document.getElementById("reg_username").value,
        email: document.getElementById("reg_email").value,
        password: document.getElementById("reg_password").value,
        is_admin: document.getElementById("reg_role_admin").checked
    };

    fetch(`${baseURL}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    })
    .then(res => {
        if (!res.ok) throw new Error("Registration failed");
        return res.json();
    })
    .then(() => {
        alert("✅ Registered successfully! Please login.");
        showLogin();
    })
    .catch(() => alert("❌ Registration failed. Try a different username or email."));
}

// 🔐 LOGIN
function login() {
    const username = document.getElementById("login_username").value;
    const password = document.getElementById("login_password").value;

    const formData = new URLSearchParams();
    formData.append("username", username);
    formData.append("password", password);

    fetch(`${baseURL}/token`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: formData
    })
    .then(res => {
        if (!res.ok) throw new Error("Login failed");
        return res.json();
    })
    .then(async (data) => {
        token = data.access_token;
        alert("✅ Login successful!");
        showDashboard();
        await checkIfAdmin();
        loadProducts();
    })
    .catch(() => alert("❌ Login failed. Invalid credentials."));
}

// Check if user is admin
async function checkIfAdmin() {
    const res = await fetch(`${baseURL}/users/me`, {
        headers: { Authorization: `Bearer ${token}` }
    });
    const user = await res.json();
    if (user.is_admin) {
        isAdmin = true;
        document.getElementById("adminSection").style.display = "block";
    } else {
        isAdmin = false;
        document.getElementById("adminSection").style.display = "none";
    }
}

// 🛍️ Load Products
function loadProducts() {
    fetch(`${baseURL}/products`)
        .then(res => res.json())
        .then(products => {
            const list = document.getElementById("productList");
            list.innerHTML = "";
            products.forEach(p => {
                const item = document.createElement("div");
                item.innerHTML = `
                    <b>${p.name}</b> - ₹${p.price} <br>
                    ${p.description || ""} <br>
                    <button onclick="addToCart(${p.id})">Add to Cart</button>
                    <hr>`;
                list.appendChild(item);
            });
        });
}

// ➕ Add to Cart
function addToCart(productId) {
    fetch(`${baseURL}/cart`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ product_id: productId, quantity: 1 })
    })
    .then(res => {
        if (!res.ok) throw new Error("Add to cart failed");
        alert("✅ Added to cart");
    })
    .catch(() => alert("❌ Failed to add to cart"));
}

// 🛒 View Cart
function viewCart() {
    fetch(`${baseURL}/cart`, {
        headers: { "Authorization": `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(cart => {
        const list = document.getElementById("cartList");
        list.innerHTML = "<h4>🛒 Your Cart:</h4>";
        if (cart.length === 0) {
            list.innerHTML += "Cart is empty.";
        } else {
            cart.forEach(item => {
                list.innerHTML += `Product ID: ${item.product_id}, Quantity: ${item.quantity}<br>`;
            });
        }
    });
}

// ✅ Place Order
function placeOrder() {
    fetch(`${baseURL}/orders`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
    })
    .then(res => {
        if (!res.ok) throw new Error("Failed to place order");
        alert("✅ Order placed!");
    })
    .catch(() => alert("❌ Could not place order. Cart may be empty."));
}

// 📦 View Orders
function viewOrders() {
    fetch(`${baseURL}/orders`, {
        headers: { "Authorization": `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(orders => {
        const list = document.getElementById("orderList");
        list.innerHTML = "<h4>📦 Your Orders:</h4>";
        if (orders.length === 0) {
            list.innerHTML += "No orders placed yet.";
        } else {
            orders.forEach(order => {
                list.innerHTML += `Order #${order.id} | Status: ${order.status} | Date: ${order.created_at}<br>`;
            });
        }
    });
}

// 👑 Admin: Add Product
async function addProduct() {
    const name = document.getElementById("product-name").value;
    const description = document.getElementById("product-desc").value;
    const price = parseFloat(document.getElementById("product-price").value);
    const quantity = parseInt(document.getElementById("product-qty").value);

    const response = await fetch(`${baseURL}/products`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ name, description, price, quantity_available: quantity })
    });

    if (response.ok) {
        alert("✅ Product added successfully");
        loadProducts();
    } else {
        alert("❌ Failed to add product. Check fields or admin access.");
    }
}
