import requests

url = "http://127.0.0.1:8000/orders"

headers = {
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtZWdoYSIsImV4cCI6MTc1MjU4NzY2Mn0.suq4rl6c4AHYdz3JEMH7_Vyp49r0WSWHR3LflQVN99U"
}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    print("✅ Fetched Orders:")
    print(response.json())
else:
    print("❌ Failed to fetch orders")
    print(response.status_code)
    print(response.text)
