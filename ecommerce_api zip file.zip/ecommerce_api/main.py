from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import timedelta

import models, schemas, crud, auth
from database import engine, get_db
from auth import get_current_active_user, get_current_admin, create_access_token

# ✅ FastAPI app
app = FastAPI()

# ✅ CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Create tables
models.Base.metadata.create_all(bind=engine)

# ========== AUTH ROUTES ==========
@app.post("/register", response_model=schemas.UserOut)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    return crud.register_user(user, db)

@app.post("/token", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = crud.authenticate_user(form_data.username, form_data.password, db)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid credentials")
    access_token = create_access_token(
        data={"sub": user.username},
        expires_delta=timedelta(minutes=auth.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/users/me", response_model=schemas.UserOut)
def read_users_me(current_user=Depends(get_current_active_user)):
    return current_user

# ========== PRODUCT ROUTES ==========
@app.post("/products")
def create_product(product: schemas.ProductCreate, db: Session = Depends(get_db), admin=Depends(get_current_admin)):
    return crud.create_product(product, db)

@app.get("/products")
def get_products(db: Session = Depends(get_db)):
    return crud.list_products(db)

# ========== CART ROUTES ==========
@app.post("/cart")
def add_to_cart(item: schemas.CartItemCreate, db: Session = Depends(get_db), user=Depends(get_current_active_user)):
    return crud.add_to_cart(user.id, item, db)

@app.get("/cart")
def get_cart(db: Session = Depends(get_db), user=Depends(get_current_active_user)):
    return crud.get_cart(user.id, db)

# ========== ORDER ROUTES ==========
@app.post("/orders")
def place_order(db: Session = Depends(get_db), user=Depends(get_current_active_user)):
    return crud.place_order(user.id, db)

@app.get("/orders")
def get_orders(db: Session = Depends(get_db), user=Depends(get_current_active_user)):
    return crud.get_orders(user.id, db)
