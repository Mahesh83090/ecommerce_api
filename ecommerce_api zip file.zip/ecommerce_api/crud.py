from sqlalchemy.orm import Session
from passlib.context import CryptContext
import models, schemas

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# 🔐 Password Hashing
def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

# ✅ Register
def register_user(user: schemas.UserCreate, db: Session):
    db_user = models.User(
        username=user.username,
        email=user.email,
        hashed_password=get_password_hash(user.password),
        is_admin=user.is_admin  # 👈 save admin flag
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

# 🔐 Authenticate
def authenticate_user(username: str, password: str, db: Session):
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user or not verify_password(password, user.hashed_password):
        return False
    return user

# 🛍️ Products
def create_product(product: schemas.ProductCreate, db: Session):
    db_product = models.Product(**product.dict())
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product

def list_products(db: Session):
    return db.query(models.Product).all()

# 🛒 Cart
def add_to_cart(user_id: int, item: schemas.CartItemCreate, db: Session):
    cart_item = models.CartItem(user_id=user_id, **item.dict())
    db.add(cart_item)
    db.commit()
    db.refresh(cart_item)
    return cart_item

def get_cart(user_id: int, db: Session):
    return db.query(models.CartItem).filter(models.CartItem.user_id == user_id).all()

# 📦 Orders
def place_order(user_id: int, db: Session):
    cart_items = get_cart(user_id, db)
    if not cart_items:
        raise ValueError("Cart is empty")

    order = models.Order(user_id=user_id)
    db.add(order)
    db.commit()
    db.refresh(order)

    for item in cart_items:
        order_item = models.OrderItem(
            order_id=order.id,
            product_id=item.product_id,
            quantity=item.quantity,
            price_at_order_time=item.product.price
        )
        db.add(order_item)
        db.delete(item)

    db.commit()
    db.refresh(order)
    return order

def get_orders(user_id: int, db: Session):
    return db.query(models.Order).filter(models.Order.user_id == user_id).all()
