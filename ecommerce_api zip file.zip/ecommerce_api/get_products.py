import requests

response = requests.get("http://127.0.0.1:8000/products")

if response.status_code == 200:
    print("✅ Product list:")
    for product in response.json():
        print(product)
else:
    print("❌ Failed to fetch products")
    print(response.status_code)
    print(response.text)
