import requests

# Replace with your valid token if needed
access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtZWdoYSIsImV4cCI6MTc1MjU4NzY2Mn0.suq4rl6c4AHYdz3JEMH7_Vyp49r0WSWHR3LflQVN99U"

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

cart_data = {
    "product_id": 1,     # Assuming your Wireless Mouse has ID 1
    "quantity": 2
}

response = requests.post("http://127.0.0.1:8000/cart", json=cart_data, headers=headers)

if response.status_code == 200:
    print("✅ Item added to cart:")
    print(response.json())
else:
    print("❌ Failed to add item to cart")
    print(response.status_code)
    print(response.text)
