import requests

# ✅ Your access token here (from /token)
access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtZWdoYSIsImV4cCI6MTc1MjU4NDg4N30.FORWptUIj9ACHCG_Z7P1AqfeXkuZ7oCKhynwWdaNZCs"

# ✅ API headers
headers = {
    "Authorization": f"Bearer {access_token}"
}

# ✅ URL to fetch current user info
url = "http://127.0.0.1:8000/users/me"

response = requests.get(url, headers=headers)

if response.status_code == 200:
    print("✅ Authenticated user info:")
    print(response.json())
else:
    print("❌ Failed to get user info")
    print(response.status_code)
    print(response.text)
