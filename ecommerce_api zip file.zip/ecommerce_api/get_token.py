import requests

url = "http://127.0.0.1:8000/token"

# Data must be in this exact format (form-encoded)
data = {
    "username": "megha",
    "password": "secret123"
}

headers = {
    "Content-Type": "application/x-www-form-urlencoded"
}

response = requests.post(url, data=data, headers=headers)

if response.status_code == 200:
    print("✅ Token fetched successfully:")
    print(response.json())
else:
    print("❌ Error fetching token")
    print(response.status_code)
    print(response.text)
