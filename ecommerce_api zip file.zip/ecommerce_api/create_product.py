import requests

# ✅ Replace with your valid access token if expired
access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtZWdoYSIsImV4cCI6MTc1MjU4NDg4N30.FORWptUIj9ACHCG_Z7P1AqfeXkuZ7oCKhynwWdaNZCs"

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

product_data = {
    "name": "Wireless Mouse",
    "description": "A smooth and stylish wireless mouse",
    "price": 699.00,
    "quantity_available": 50
}

response = requests.post("http://127.0.0.1:8000/products", json=product_data, headers=headers)

if response.status_code == 200:
    print("✅ Product created successfully!")
    print(response.json())
else:
    print("❌ Failed to create product")
    print(response.status_code)
    print(response.text)
