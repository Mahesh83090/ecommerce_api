import requests

# ✅ Your current access token
access_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtZWdoYSIsImV4cCI6MTc1MjU4NzY2Mn0.suq4rl6c4AHYdz3JEMH7_Vyp49r0WSWHR3LflQVN99U"

headers = {
    "Authorization": f"Bearer {access_token}"
}

response = requests.post("http://127.0.0.1:8000/orders", headers=headers)

if response.status_code == 200:
    print("✅ Order placed successfully:")
    print(response.json())
else:
    print("❌ Failed to place order")
    print(response.status_code)
    print(response.text)
