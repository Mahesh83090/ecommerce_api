from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# ======= USER SCHEMAS =======
class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str
    is_admin: bool = False  # 👈 added field for admin registration

class UserOut(BaseModel):
    id: int
    username: str
    email: EmailStr
    is_admin: bool

    class Config:
        from_attributes = True

# ======= LOGIN SCHEMAS =======
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

# ======= PRODUCT SCHEMAS =======
class ProductCreate(BaseModel):
    name: str
    description: Optional[str]
    price: float
    quantity_available: int

class ProductOut(BaseModel):
    id: int
    name: str
    description: Optional[str]
    price: float
    quantity_available: int

    class Config:
        from_attributes = True

# ======= CART SCHEMAS =======
class CartItemCreate(BaseModel):
    product_id: int
    quantity: int

class CartItemOut(BaseModel):
    id: int
    product_id: int
    quantity: int

    class Config:
        from_attributes = True

# ======= ORDER SCHEMAS =======
class OrderItemOut(BaseModel):
    product_id: int
    quantity: int
    price_at_order_time: float

    class Config:
        from_attributes = True

class OrderOut(BaseModel):
    id: int
    created_at: datetime
    status: str
    items: List[OrderItemOut]

    class Config:
        from_attributes = True
